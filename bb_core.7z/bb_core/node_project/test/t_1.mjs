import $bb from '../bb/index.mjs';

console.dir($bb);


