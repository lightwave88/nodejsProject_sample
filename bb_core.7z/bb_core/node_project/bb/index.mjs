export {
  default,
  $bb
} from '../../my_modules/bb_core/index.mjs';
