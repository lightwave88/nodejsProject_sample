const $http = require('http');
const $path = require('path');

const $domain = require('domain');
const t_domain = $domain.create();

const $port = 8082;

debugger;
let path = $path.resolve('./my_modules/simpleServer');

const {
  Server: $Server,
  mime: $mime
} = require(path);
debugger;

const $server = new $Server();
//----------------------------
$http.createServer(function ($req, $res) {
  debugger;

  t_domain.on('error', (er) => {
    _error($res, er.toString());
  });

  t_domain.run(() => {
    $server.createRequest($req, $res);
  });

}).listen($port);

//----------------------------
function _error(res, info) {
  console.log(info);

  res.writeHead(200, {
    'Content-Type': 'text/html',
    'charset': 'utf-8',
  });
  info = `<div>${info}</div>`;

  res.end(info);
}
