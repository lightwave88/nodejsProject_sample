let $MB;

const $c = {
  name: 'c',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
		console.dir($MB.modules());
  }
};
//-------------
function loaded(mb){
  console.log('c...');
  console.dir(this.modules());
	console.log('----------');
}
//-------------
function handle(mb) {
  debugger;
  $MB = mb;
  $MB.onload(loaded);
  return $c;
}
//-------------
export {
  handle
};
