debugger;

import {
  ModuleBridge
} from '../../../moduleBridge.js';
const $MB = new ModuleBridge();
//-----------------------
import {
  handle as h_c
} from './c.js';

// c 只在此區塊可以看到
$MB.importHandle('c', h_c);
//-----------------------
// 對外輸出
function handle(mb) {
  debugger;
  $MB.linkParent(mb);

  const c = $MB.get('c');
  return c;
}

export {
  handle
};
