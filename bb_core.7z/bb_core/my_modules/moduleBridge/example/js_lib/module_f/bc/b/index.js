debugger;

import {
	ModuleBridge
} from '../../../moduleBridge.js';
const $MB = new ModuleBridge();
//-----------------------
import {
	handle as h_b
} from './b.js';

// 對外輸出 b
$MB.importHandle('b', h_b);

//-----------------------

// 對外輸出
$MB.export(function(mb) {
	debugger;
	const b = this.get('b');
	return b;
});

export default $MB;