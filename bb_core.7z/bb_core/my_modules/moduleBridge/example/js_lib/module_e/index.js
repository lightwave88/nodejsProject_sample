debugger;

import {
  ModuleBridge
} from '../moduleBridge.js';

const $MB = new ModuleBridge();
//-----------------------
import {
  handle as h_a
} from './a.js';

$MB.importHandle('a', h_a);
//-----------------------
import module_b from './b/index.js';
$MB.import(['b', 'c'], module_b);
//-----------------------
// 對外輸出
function handle(outsideMoudule) {

  // 引入外部 outsideMoudule
  $MB.import('outside', outsideMoudule);
  
  debugger;
  $MB.finish();  

  const a = $MB.get('a');
  const b = $MB.get('b');
  const c = $MB.get('c');

  return {
    a,
    b,
    c
  };
}

export {
  handle
};