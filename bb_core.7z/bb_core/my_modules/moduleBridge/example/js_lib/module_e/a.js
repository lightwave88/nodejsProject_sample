debugger;

let $MB;

const $a = {
  name: 'a',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());	
  }
};

function handle(mb) {
  debugger;
  $MB = mb;
  return $a;
}

export {
  handle
};