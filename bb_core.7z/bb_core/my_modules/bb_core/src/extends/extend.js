let $bb;
const $extend = {};

const {
	$Promise,
	$Deferred,
} = (() => {
	class Pr extends Promise {
		constructor(executor) {
			// debugger;
			// console.log(executor.toString());
			super((resolve, reject) => {
				return executor(resolve, reject);
			});
		}
		//------------------
		always(callback) {
			// debugger;
			let p = this.then((d) => {
				// debugger;
				return callback(null, d);
			}, (er) => {
				// debugger;
				return callback(er);
			});
			// 反囘原有的 promise
			// p = Promise.resolve(p);
			// debugger;
			return p;
		}
	}
	//-------------------------------------------
	class Def {
		$handle;
		$pr;
		constructor(timeout = null) {

			this.$pr = new Pr(($res, $rej) => {
				this.$handle = (function*() {
					// debugger;
					let {
						error,
						data
					} = yield;

					// debugger;
					if (error == null) {
						$res(data);
					} else {
						$rej(error);
					}
				})();
				this.$handle.next();
			});
			//------------------
			// 計時器
			if (typeof timeout == 'number') {
				setTimeout(() => {
					this.$handle.next({
						error: (new TimeoutError()),
						data: null
					});
				}, timeout);
			}
		}
		//------------------------------------------------
		get promise() {
			return this.$pr;
		}
		//------------------------------------------------
		resolve(data) {
			this.$handle.next({
				error: null,
				data
			});
		}
		//------------------------------------------------
		reject(er) {
			this.$handle.next({
				error: er,
				data: null
			});
		}
	}

	return {
		$Promise: Pr,
		$Deferred: Def,
	}
})();
//--------------------------------------
class TimeoutError extends Error {
	toString() {
		return 'timeoutError';
	}

	toJSON() {
		return 'timeoutError';
	}
}

////////////////////////////////////////////////////////////////////////////////
{
	// tools.getUid(namespace)
	//
	// 取得獨一無二的 id
	const $guid = {
		namespace: {},
		uid: 0,
		getUid(namespace = null) {

			if (namespace == null) {

			} else if (typeof(namespace) == 'string') {
				namespace = namespace.trim();
				namespace = (namespace.length > 0) ? namespace : null;
			} else if (typeof(namespace) == 'symbol') {

			} else {
				throw new TypeError('...');
			}

			if (namespace == null) {
				return this.uid++;
			}
			if (!(namespace in this.namespace)) {
				this.namespace[namespace] = 0;
			}
			return this.namespace[namespace]++;
		}
	};
	// API
	function getUid(namespace) {
		return $guid.getUid(namespace);
	}
	//------------------
	$extend.$getUid = getUid;
	$extend.getUid = getUid;
}
//------------------------------------------------------------------------------
{
	// tools.isPlainObject(obj)
	//
	const reg_1 = /^\[object Object\]$/;

	const proto_toString = Object.prototype.toString;
	const class2type = {};
	const class2typeCts = {}.constructor;
	const hasOwn = class2type.hasOwnProperty;

	// from jquery
	function isPlainObject(obj) {
		// debugger;
		let proto;
		let Ctor;
		let res;

		if (typeof obj != 'object') {
			return false;
		}
		// Detect obvious negatives
		// Use toString instead of jQuery.type to catch host objects
		res = proto_toString.call(obj);
		res = reg_1.test(res);

		if (!obj || !res) {
			return false;
		}
		proto = Object.getPrototypeOf(obj);

		// Objects with no prototype (e.g., `Object.create( null )`) are plain
		if (!proto) {
			return true;
		}
		// Objects with prototype are plain iff they were constructed by a global Object function
		Ctor = hasOwn.call(proto, "constructor") && proto.constructor;

		return (typeof Ctor == "function" && Ctor === class2typeCts);
	}
	//------------------
	$extend.$isPlainObject = isPlainObject;
	$extend.isPlainObject = isPlainObject;
}

//------------------------------------------------------------------------------
{
	// tools.getClass(obj)
	//
	function getClass(data) {
		// debugger;
		const $toString = Object.prototype.toString;

		let _class = null;

		let str_1 = $toString.call(data);
		let res = /\[\w+\s+(\w+)\]/.exec(str_1);

		res = (res == null) ? [] : res;
		([, _class] = res);
		return _class;
	}
	//------------------
	$extend.$getClass = getClass;
	$extend.getClass = getClass;
}
//------------------------------------------------------------------------------
{
	// tools.timeout(timeLimit, promise)
	//
	// timeout 時間到了會 reject
	class _TimeOut {
		$def;
		$timeHandle;
		$finish;
		//---------------------------------
		constructor(timeLimit, pr) {
			// debugger;

			if (!(pr instanceof Promise)) {
				throw new TypeError('$bb.timeout(,pr) pr not instanceof Promise');
			}
			//---------------
			const def = this.$def = new $Deferred();

			// 計時器
			this.$timeHandle = setTimeout(() => {
				// debugger;
				def.reject(new TimeoutError());
				this._clear();
			}, timeLimit);
			//---------------
			pr.then((data) => {
				this._clear();
				def.resolve(data);
			}, (err) => {
				this._clear();
				def.reject(err);
			});
		}
		//---------------------------------
		get promise() {
			return this.$def.promise;
		}
		//---------------------------------
		_clear() {
			clearTimeout(this.$timeHandle);
			this.$timeHandle = null;
		}
	}

	function timeout(timeLimit, pr) {
		let to = new _TimeOut(timeLimit, pr);
		return to.promise;
	}
	//------------------
	$extend.$timeout = timeout;
	$extend.timeout = timeout;
}
//------------------------------------------------------------------------------
{
	// setTimeout(time, fun = null)
	//
	// 事間到了會 resolve
	// setTimeout(null, time) 類似 sleep(time)
	function setTimeout(time, fun = null) {

		if (typeof fun != 'function') {
			throw new TypeError("$bb.detTimeout(, fun), fun must be function");
		}
		const def = new $Deferred();
		//---------------
		setTimeout(() => {
			// debugger;
			let $res;
			let $er;
			let i = 0;

			if (fun != null) {
				try {
					$res = fun();
				} catch (er) {
					$er = er;
					i++;
				}
			}

			if (i > 0) {
				def.reject($er);
			} else {
				def.resolve($res);
			}
		}, time);
		return def.promise;
	}
	//------------------
	$extend.$setTimeout = setTimeout;
	$extend.setTimeout = setTimeout;
}
//------------------------------------------------------------------------------
{
	// tools.promise(callback)
	//
	function $promise(callback, context = null) {
		if (typeof(callback) != "function") {
			throw new TypeError("bb.promise(callback) callback must be function");
		}
		if (context != null) {
			callback = callback.bind(context);
		}
		let p = new $Promise(callback);
		return p;
	}
	$promise.resolve = function(d) {
		return $Promise.resolve(d);
	};
	$promise.reject = function(er) {
		return $Promise.reject(er);
	};
	$promise.all = function(list) {
		return $Promise.all(list);
	}
	$promise.race = function(list) {
		return $Promise.race(list);
	}
	//------------------
	$extend.$promise = $promise;
	$extend.promise = $promise;
}

//------------------------------------------------------------------------------
{
	function deferred(timeout) {
		return new $Deferred(timeout);
	}
	//------------------
	$extend.$deferred = deferred;
	$extend.deferred = deferred;
}
//------------------------------------------------------------------------------
{
	const $bucket = new Map();

	function $symbol(name) {
		let res;
		if (typeof(name) == 'symbol') {
			for (let [key, vale] of $bucket) {
				if (value === name) {
					res = key;
					break;
				}
			}
		} else if (typeof(name) == 'string') {
			if (!$bucket.has(name)) {
				$bucket.set(name, Symbol(name));
			}
			res = $bucket.get(name);
		}
		return res;
	}
	//------------------
	// 系統內部共享的 symbol
	// tools.symbol(name)
	// 設定取得 symbol
	$extend.$symbol = $symbol;
	$extend.symbol = $symbol;
}
//------------------------------------------------------------------------------
{
	// tools.copyValue(data)
	//
	// 複製 data 的值
	function copyValue(data) {
		// debugger;
		let checkList = [];
		checkList.push(new Item(data, null, null));

		let i = 0;
		while (i < checkList.length) {
			// debugger;
			let j = i++;

			let item = checkList[j];
			item.setIndex(j);
			let childs = item.checkChilds();

			childs.forEach((item) => {
				checkList.push(item);
			});
		} // while
		//-------------
		// console.dir(checkList);
		// debugger;
		let item;
		while (checkList.length) {
			// debugger;
			item = checkList.pop();
			if (!item.hasParent()) {
				break;
			}
			item.callParent(checkList);
		} // while

		let clone = item.clone;
		return clone;
	};
	//-----------------------
	class Item {
		$type;
		$checkList;
		$key;
		$pIndex;
		$index;
		//-------------
		// 原始值
		$value;
		$clone;
		//-----------------------
		get clone() {
			let res = (this.$clone != null) ? this.$clone : this.$value;
			return res;
		}
		//-----------------------
		constructor(data, pIndex = null, key = null) {
			debugger;

			// this.$checkList = checkList;
			this.$value = data;
			this.$pIndex = pIndex;
			this.$key = key;
			this.$type = $extend.getClass(data);

			switch (this.$type) {
				case 'Object':
					this.$clone = {};
					break;
				case 'Array':
					this.$clone = [];
					this.$clone.length = this.$value.length;
					break;
				case 'Map':
					this.$clone = new Map();
					break;
				case 'Set':
					this.$clone = new Set();
					break;
				default:
					break;
			} // switch
		}
		//-----------------------
		hasParent() {
			let res = (this.$pIndex != null);
			return res;
		}
		//-----------------------
		setIndex(i) {
			this.$index = i;
		}
		//-----------------------
		callParent(checkList) {
			debugger;

			let pIndex = this.$pIndex;

			// console.log('pIndex(%s)', pIndex);

			let parent = checkList[pIndex];
			// let value = (this.$clone != null) ? this.$clone : this.$value;
			let value = this.clone;
			parent.setValue(this.$key, value);
			// this.$value = null;
		}
		//-----------------------
		// call by child
		setValue(key, value) {
			let $data = this.$clone;

			switch (this.$type) {
				case 'Object':
				case 'Array':
					$data[key] = value;
					break;
				case 'Map':
					$data.set(key, value);
					break;
				case 'Set':
					$data.add(value);
					break;
				default:
					throw new TypeError(`no support this type(${typeof ($data)})`);
					break;
			}
		}
		//-----------------------
		checkChilds() {
			// debugger;

			let index = this.$index;
			let $childs = [];
			const $data = this.$value;

			switch (this.$type) {
				case 'Object':
					for (let key in $data) {
						let value = $data[key];
						let item = new Item(value, index, key);
						$childs.push(item);
					}
					break;
				case 'Array':
					for (var i = 0; i < $data.length; i++) {
						let value = $data[i];
						let item = new Item(value, index, i);
						$childs.push(item);
					}
					break;
				case 'Map':
					for (let [key, value] of $data) {
						// debugger;

						let key_1;
						if (key != null && typeof key == 'object') {
							// here
							// here
							key_1 = $extend.copyValue(key);
						} else {
							key_1 = key;
						}
						//------------------
						// debugger;
						let item = new Item(value, index, key_1);
						$childs.push(item);
					}
					$childs.reverse();
					break;
				case 'Set':
					for (let value of $data) {
						let item = new Item(value, index);
						$childs.push(item);
					}
					$childs.reverse();
					break;
				default:
					break;
			}
			return $childs;
		}
	}
	//------------------
	$extend.$copyValue = copyValue;
	$extend.copyValue = copyValue;
}
//------------------------------------------------------------------------------
export function handle(bb) {
	$bb = bb;

	for (let name in $extend) {
		if (name in $bb) {
			throw new Error(`${name} has exists`);
		}
		$bb[name] = $extend[name];
	}
	return $extend;
};